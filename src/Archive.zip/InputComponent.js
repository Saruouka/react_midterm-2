import React, {Component, PropTypes} from 'react';

export class InputComponent extends Component 
{
  static propTypes = {
      partText: PropTypes.string,
      scoreText: PropTypes.parseInt
  }

  state = {
    gpax: 0,onet01: 0,onet02: 0,onet03: 0,onet04: 0,onet05: 0,gat:0,pat1: 0,pat2: 0,pat3: 0,pat4: 0,pat5: 0,pat6: 0,pat7: 0,
    total: 0
  }

  ScoreCalc = (event) =>
  {
      var Gpax = this.state.gpax;
      var Onet01 = this.state.onet01;
      var Onet02 = this.state.onet02;
      var Onet03 = this.state.onet03;
      var Onet04 = this.state.onet04;
      var Onet05 = this.state.onet05;
      var Gat = this.state.gat;
      var Pat1 = this.state.pat1;
      var Pat2 = this.state.pat2;
      var Pat3 = this.state.pat3;
      var Pat4 = this.state.pat4;
      var Pat5 = this.state.pat5;
      var Pat6 = this.state.pat6;
      var Pat7 = this.state.pat7;
      var OnetTotal = parseFloat(Onet01)+parseFloat(Onet02)+parseFloat(Onet03)+parseFloat(Onet04)+parseFloat(Onet05)
      var result = (parseFloat(Gpax)*1500)+(OnetTotal*18)+(parseFloat(Pat2)*(30/100)+parseFloat(Gat)*(30/100));

      this.setState({total: result});
  }
  
  GetGpax = (event) =>
  {
      this.setState({gpax: event.target.value});
  }
  GetPat01 = (event) =>
  {
      this.setState({pat1: event.target.value});
  }
  GetPat02 = (event) =>
  {
      this.setState({pat2: event.target.value});
  }
  GetPat03 = (event) =>
  {
      this.setState({pat3: event.target.value});
  }
  GetPat04 = (event) =>
  {
      this.setState({pat4: event.target.value});
  }
  GetPat05 = (event) =>
  {
      this.setState({pat5: event.target.value});
  }
  GetPat06 = (event) =>
  {
      this.setState({pat6: event.target.value});
  }
  GetPat07 = (event) =>
  {
      this.setState({pat7: event.target.value});
  }
  
  GetGat = (event) =>
  {
      this.setState({gat: event.target.value});
  }

  GetOnet01 = (event) =>
  {
      this.setState({onet01: event.target.value});
  }
  GetOnet02 = (event) =>
  {
      this.setState({onet02: event.target.value});
  }
  GetOnet03 = (event) =>
  {
      this.setState({onet03: event.target.value});
  }
  GetOnet04 = (event) =>
  {
      this.setState({onet04: event.target.value});
  }
  GetOnet05 = (event) =>
  {
      this.setState({onet05: event.target.value});
  }

  render() 
  {
   
    return (   
      <div className="test">
          <div className="row">
              <div className="col-md-12 App-headpart test">
                    {this.props.partText}
              </div>
          </div>
          <div className="row App-box">
              <div className="col-md-6 App-content">
                GPAX (ไม่เกิน 4.00)
                <center><input type="text" onChange={this.GetGpax} placeholder="GPAX" className="form-test"/></center>
                Onet (คะแนนเต็ม 100)
                <center>
                    <input type="text" onChange={this.GetOnet01} placeholder="01 ภาษาไทย" className="form-test"/>
                    <input type="text" onChange={this.GetOnet02} placeholder="02 สังคม" className="form-test"/>
                    <input type="text" onChange={this.GetOnet03} placeholder="03 ภาษาอังกฤษ" className="form-test"/>
                    <input type="text" onChange={this.GetOnet04} placeholder="04 คณิตศาสตร์" className="form-test"/>
                    <input type="text" onChange={this.GetOnet05} placeholder="05 วิทยาศาสตร์" className="form-test"/>
                </center>
                GAT (คะแนนเต็ม 300)
                <center><input type="text" onChange={this.GetGat} placeholder="GAT" className="form-test"/></center>
              </div>
              <div className="col-md-6 App-content">
                PAT (คะแนนเต็ม 300)
                <center>
                    <input type="text" onChange={this.GetPat01} placeholder="PAT1 คณิตศาสตร์" className="form-test"/>
                    <input type="text" onChange={this.GetPat02} placeholder="PAT2 วิทยาศาสตร์" className="form-test"/>
                    <input type="text" onChange={this.GetPat03} placeholder="PAT3 วิศวกรรม" className="form-test"/>
                    <input type="text" onChange={this.GetPat04} placeholder="PAT4 สถาปัตยกรรม" className="form-test"/>
                    <input type="text" onChange={this.GetPat05} placeholder="PAT5 วิชาชีพครู" className="form-test"/>
                    <input type="text" onChange={this.GetPat06} placeholder="PAT6 ศิลปกรรม" className="form-test"/>
                    <input type="text" onChange={this.GetPat07} placeholder="PAT7 ความถนัดทางภาษา" className="form-test"/>
                </center>
              </div>
              <div className="col-md-12 App-content">
              <button onClick={this.ScoreCalc} className="btn-primary">คำนวณ</button>
              you got {this.state.total}
              </div>
          </div>
      </div>
    );
  }
}